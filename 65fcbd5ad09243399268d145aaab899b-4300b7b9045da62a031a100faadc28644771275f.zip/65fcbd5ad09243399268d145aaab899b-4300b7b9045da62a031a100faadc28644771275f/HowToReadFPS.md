Atmosphere CFW is required. SX OS and other CFWs are not supported.
It's advised to use Atmosphere's USB Transfer Tool homebrew to transfer files. If you use Hekate's USB Mass Storage and you will be putting files using any other Operating System than Windows, you must run Hekate's Archive Bit Fixer after putting all files.

1. Download newest `SaltyNX` release from [HERE](https://github.com/masagrator/SaltyNX/releases), unpack zip file, copy both folders (`SaltySD` and `atmosphere`) to the root of your sdcard, accept any popup about overwriting folders.
2. Download newest `NX-FPS` release from [HERE](https://github.com/masagrator/NX-FPS/releases), unpack zip file, copy `SaltySD` folder to the root of sdcard, accept any popup about overwriting folders.
3. Download newest `nx-ovlloader` release from [HERE](https://github.com/WerWolv/nx-ovlloader/releases), unpack zip file, copy `atmosphere` folder to the root of sdcard, accept any popup about overwriting folders.
4. Download newest `Tesla Menu` release from [HERE](https://github.com/WerWolv/Tesla-Menu/releases), copy `switch` folder to the root of sdcard, accept any popup about overwriting folders.
5. Download `Status Monitor Overlay` release from [HERE](https://github.com/masagrator/Status-Monitor-Overlay/releases), copy `Status-Monitor-Overlay.ovl` to `switch\.overlays` folder. It may not be visible in USB Mass Storage, but it's there.
6. Download `FPSLocker` release from [HERE](https://github.com/masagrator/FPSLocker/releases), copy `FPSLocker.ovl` to `switch\.overlays` folder. It may not be visible in USB Mass Storage, but it's there.
8. Restart Switch, now you can access overlays by pressing all 3 buttons at once: `L`, `D-pad down` and `R-stick` (aka pressing it).

Additionally for FPSLocker download newest set of patches from [FPSLocker Warehouse](https://github.com/masagrator/FPSLocker-Warehouse) for games that need more things to be tweaked to get proper FPS boost.

In case of any other question read READMEs of those tools.